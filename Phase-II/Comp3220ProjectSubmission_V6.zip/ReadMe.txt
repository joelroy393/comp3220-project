Comp3220Project_V6:
	Setup for database:
	- Requires activation of MySQL and apache using xampp
	- Go to a browser and search "localhost", navigating to the
	  PhpMyAdmin page.
	- Create a new database called "cityofwindsor"
	- Import the cityofwindsor sql source file inside of DB into the
	  MySQL.

	Setup project on eclipse:
	- Comp3220Project1 contains the eclipse project
	- Navigate to your eclipse workspace in your folders and move
	  the file inside
	- Run eclipse and Right click on the project, go to  Build path >	  build dependency > Add external jar( jdbc connector )

UML Diagrams:
	Contains all UML Diagrams used throughout Phase II