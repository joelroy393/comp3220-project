import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Main {
	public static void main(String args[]) throws ClassNotFoundException {
		System.out.println("Hello World");
		
		MySQLDatabaseConnection conn = new MySQLDatabaseConnection("jdbc:mysql://localhost:3306/cityofwindsor", "root", "");
		try {
			conn.getConnection();// print "Database connection established" if successful
		}catch(SQLException e) {
			System.err.println("Failed to establish database connection: " + e.getMessage());
			
		}/*finally {
            try {
                con.closeConnection();  // This will print "Database connection closed" if successful
            } catch (SQLException e) {
                System.err.println("Failed to close database connection: " + e.getMessage());
            }
		} */
		
		//Class.forName("com.mysql.cj.jdbc.Driver");
		
		
		//System.out.println("connection created");
		
		
		//This is for testing
		UIManagement frame = new UIManagement();
		frame.setVisible(true);

		for(int i = 0; i < 10; i ++) {
			CatalogEntry newEntry = new CatalogEntry("311 Windsor Contact Centre Metrics 2021", "This dataset outlines a number of key performance indicators in the Windsor 311 Contact Centre calculated on a yearly basis.");
			FilePoint newFile = new FilePoint("ID1", "311 Windsor Contact Centre Metrics 2021", 102, ".xlsx", "No Path");
			newEntry.setDataCustodian(i);
			newEntry.setDataCurrency("The data will be updated annually and posted early in the following year");
			newEntry.setDatasetDescription("\r\n"
					+ "This dataset outlines a number of key performance indicators in the Windsor 311 Contact Centre calculated on a yearly basis. This information is used by 311 for planning and business purposes and provides customers an understanding of the volume of interactions and overall trends.");
			newEntry.setDataAccuracy("\r\n"
					+ "This set represents data extracted from the Contact Centre phone system as well as through the customer relationship management software.");
			newEntry.setAttributes("\r\n"
					+ "Calls Answered: A numerical value representing the total number of phone calls answered annually.\r\n"
					+ "Average Answer Delay: A numeric calculation representing the average amount of time waiting in queue prior to live answer.\r\n"
					+ "Service Level Target: A numeric value which measures how quickly customers are being served, expressed as a percentage of incoming calls being answered within a specific time frame. The Windsor 311 Service Level Target is 75/45 indicating that the goal is to answer 75% of calls within 45 seconds.\r\n"
					+ "Average Length of Call: A numeric value presented in minutes indicating the average amount of time taken to address a customer telephone interaction.\r\n"
					+ "First Call Resolution Rate: A numeric calculation indicating the percentage of calls that addressed the customers need on the first call thus eliminating the need to transfer that call to another department.\r\n"
					+ "311 Knowledge Base Inquiries: A numeric value representing the number of inquiries categorized where questions were answered or information was provided the customer.\r\n"
					+ "311 Service Requests: A numeric value representing the total number of customer initiated or proactive service requests entered in the customer relationship management software.\r\n"
					+ "311 Online: A numeric value representing the total number of customer initiated service requests entered through the online channel.\r\n"
					+ "311 Texts: A numeric value representing the total number of customer initiated inquiries received and responded to via the text channel.\r\n"
					+ "311 Email: A numeric value representing the total number of customer initiated inquiries received and responded to via the email channel.\r\n"
					+ "311 Mobile App: A numeric value representing the total number of customer initiated requests received via the Windsor 311 mobile app.");
			newEntry.addDownloadFiles(newFile);
			frame.addToCatalog(newEntry);
		}
		frame.updateCatalog();
		//frame.updateDataSet();
		
	}
}
