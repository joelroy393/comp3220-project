import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.FlowLayout;
import javax.swing.JScrollPane;
import javax.swing.BoxLayout;
import javax.swing.JLayeredPane;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JToolBar;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JTextField;
import javax.swing.JTable;

public class Administrator extends JFrame {

	//Temp methods so no errors pop up
	public void updateCatalog() {
		
	}
	
	
	
	
	//End of temp methods
	private String fullName;
	private List<String> approvals = new ArrayList<>();
	private List<String> accounts = new ArrayList<>();

	public Administrator() {
		setBounds(100, 100, 845, 664);
		
        contentPane = new JPanel();
        contentPane.setBackground(new Color(255, 255, 255)); // Updated color
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.X_AXIS));
		
		JLayeredPane layeredPane = new JLayeredPane();
		contentPane.add(layeredPane);
		
		JLabel lbl1 = new JLabel("City of Windsor Open Data Catalog");
		lbl1.setFont(new Font("Yu Gothic", Font.BOLD, 14));
		lbl1.setBounds(22, 10, 253, 33);
		layeredPane.add(lbl1);
		
		JButton btnLogOut = new JButton("Log Out");
		btnLogOut.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				updateCatalog();
			}
		});
		btnLogOut.setBackground(new Color(255, 255, 255));
		btnLogOut.setBounds(666, 10, 119, 27);
		layeredPane.add(btnLogOut);
		
		JLabel lblJoseph;
		if (fullName != null) {
			lblJoseph = new JLabel(fullName + " (Administrator)");
		}
		else {
			lblJoseph = new JLabel("Example Name" + " (Administrator)");
		}
		lblJoseph.setFont(new Font("Yu Gothic", Font.BOLD, 18));
		lblJoseph.setBounds(22, 72, 288, 48);
		layeredPane.add(lblJoseph);
		
		JButton btnApprovals = new JButton("My Recent Approvals");
		btnApprovals.setFont(new Font("Yu Gothic", Font.BOLD, 10));
		btnApprovals.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Approvals Clicked");
			}
		});
		btnApprovals.setBounds(22, 117, 153, 48);
		layeredPane.add(btnApprovals);
		
		JButton btnAnalytics = new JButton("Analytics");
		btnAnalytics.setFont(new Font("Yu Gothic", Font.BOLD, 10));
		btnAnalytics.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Analytics Clicked");
			}
		});
		btnAnalytics.setBounds(222, 117, 153, 48);
		layeredPane.add(btnAnalytics);
		
		JButton btnUpload = new JButton("Upload a New Dataset");
		btnUpload.setFont(new Font("Yu Gothic", Font.BOLD, 10));
		btnUpload.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Upload Clicked");
			}
		});
		btnUpload.setBounds(22, 197, 153, 48);
		layeredPane.add(btnUpload);
		
		JButton btnAccount = new JButton("Manage Accounts");
		btnAccount.setFont(new Font("Yu Gothic", Font.BOLD, 10));
		btnAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Account Clicked");
			}
		});
		btnAccount.setBounds(222, 197, 153, 48);
		layeredPane.add(btnAccount);
		
		JPanel panel = new JPanel();
		panel.setBounds(22, 284, 533, 253);
		layeredPane.add(panel);
		panel.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel = new JLabel("Pending Review");
		lblNewLabel.setFont(new Font("Yu Gothic", Font.BOLD, 18));
		panel.add(lblNewLabel, BorderLayout.NORTH);
		
		JScrollPane scrollPane = new JScrollPane();
		panel.add(scrollPane, BorderLayout.CENTER);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		
	}

	
	private JPanel contentPane;
	private JTable table;


	/**
	 * Create the frame.
	 */
	public JPanel administrator() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 845, 664);
		setContentPane(contentPane);
		
		
		return contentPane;
	}
}
