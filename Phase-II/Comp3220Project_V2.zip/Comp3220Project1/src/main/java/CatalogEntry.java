import java.util.ArrayList;
import java.util.List;

/*
 * DatabaseEntry Interface
 * Last Updated: 2024-11-05
 * Purpose: Serves as a holder for a database entry on the main page. This holds the associated files
 * 			as well as the data point title and description
 * */
public class CatalogEntry {
	public String title;
	public String description;
	public List<String> keywords = new ArrayList<>();
	//public List<FilePoint> file;
	
	public CatalogEntry(String title, String description) {
		this.title = title;
		this.description = description;
	}
	
	public void setKeywordList(List<String> keywords) {
		this.keywords = keywords;
	}
	
	public void addKeyword(String keyword) {
		keywords.add(keyword);
	}

	public void clearKeywords() {
		keywords.clear();
	}
	
	/*TODO:REMOVE ALL COMMENTS WHEN COMBINING
	public void addFile(FilePoint file) {
		this.file.add(file);
	}
	
	
	public clearFile() {
		file.clear();
	}
	*/
}
