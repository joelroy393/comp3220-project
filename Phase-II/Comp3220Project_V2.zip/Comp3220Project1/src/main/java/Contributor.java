import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.BorderLayout;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Contributor extends JFrame {
	public void updateCatalog() {};
	
	private JPanel contentPane;
	private String fullName;

	/**
	 * Create the frame.
	 */
	public Contributor() {
		setBounds(100, 100, 845, 664);
		
        contentPane = new JPanel();
        contentPane.setBackground(new Color(255, 255, 255)); // Updated color
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.X_AXIS));
		
		JLayeredPane layeredPane = new JLayeredPane();
		contentPane.add(layeredPane);
		
		JLabel lbl1 = new JLabel("City of Windsor Open Data Catalog");
		lbl1.setFont(new Font("Yu Gothic", Font.BOLD, 14));
		lbl1.setBounds(22, 10, 253, 33);
		layeredPane.add(lbl1);
		
		JButton btnLogOut = new JButton("Log Out");
		btnLogOut.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				updateCatalog();
			}
		});
		btnLogOut.setBackground(new Color(255, 255, 255));
		btnLogOut.setBounds(666, 10, 119, 27);
		layeredPane.add(btnLogOut);
		
		JLabel lblName;/*
		if (fullName != null) {
			lblJoseph = new JLabel(fullName + " (Contributor)");
		}
		else {*/
			lblName = new JLabel("Example Name" + " (Contributor)");
		//}
		lblName.setFont(new Font("Yu Gothic", Font.BOLD, 18));
		lblName.setBounds(22, 72, 288, 48);
		layeredPane.add(lblName);
		
		JButton btnUpload = new JButton("Upload a New Dataset");
		btnUpload.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnUpload.setBounds(22, 115, 174, 48);
		layeredPane.add(btnUpload);
		
		JPanel panelContribution = new JPanel();
		panelContribution.setBounds(22, 188, 436, 187);
		layeredPane.add(panelContribution);
		panelContribution.setLayout(new BorderLayout(0, 0));
		
		JLabel lblContribution = new JLabel("My Contributions");
		lblContribution.setFont(new Font("Yu Gothic", Font.BOLD, 16));
		panelContribution.add(lblContribution, BorderLayout.NORTH);
		
		JScrollPane scrollPane = new JScrollPane();
		panelContribution.add(scrollPane, BorderLayout.CENTER);
		
		JTextArea txtContribution = new JTextArea();
		txtContribution.setForeground(new Color(34, 170, 0));
		txtContribution.setFont(new Font("Monospaced", Font.PLAIN, 12));
		txtContribution.setWrapStyleWord(true);
		txtContribution.setLineWrap(true);
		scrollPane.setViewportView(txtContribution);
		
		JPanel panelDataSet = new JPanel();
		panelDataSet.setBounds(22, 401, 436, 187);
		layeredPane.add(panelDataSet);
		panelDataSet.setLayout(new BorderLayout(0, 0));
		
		JLabel lblPending = new JLabel("My Pending Datasets");
		lblPending.setFont(new Font("Yu Gothic", Font.BOLD, 16));
		panelDataSet.add(lblPending, BorderLayout.NORTH);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		panelDataSet.add(scrollPane_1, BorderLayout.CENTER);
		
		JTextArea txtPending = new JTextArea();
		txtPending.setWrapStyleWord(true);
		txtPending.setLineWrap(true);
		txtPending.setForeground(new Color(34, 170, 0));
		txtPending.setFont(new Font("Monospaced", Font.PLAIN, 12));
		scrollPane_1.setViewportView(txtPending);
		
		
	
	
	}
}
