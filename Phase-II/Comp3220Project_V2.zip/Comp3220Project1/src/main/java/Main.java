import javax.swing.JButton;
import javax.swing.JFrame;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Main {
	public static void main(String args[]) throws ClassNotFoundException, SQLException {
		System.out.println("Hello World");
		
		
		/*
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/unisoft","","");
		System.out.println("connection created");
		*/
		
		//This is for testing
		UserManagement testManage = new UserManagement("C:\\Users\\jonat\\OneDrive\\Desktop\\test.txt");	
		System.out.println(testManage.login("usernajyme3", "password3"));
			
		UIManagement frame = new UIManagement();
		frame.setVisible(true);
		
		for(int i = 0; i < 15; i ++) {
			CatalogEntry newEntry = new CatalogEntry("Testing Area: " + i, "Lorem ipsum dolor sit amet");
			frame.addToCatalog(newEntry);
		}
		frame.updateCatalog();
		
	}
}
