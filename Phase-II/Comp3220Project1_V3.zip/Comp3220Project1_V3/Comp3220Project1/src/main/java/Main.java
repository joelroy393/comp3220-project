import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Main {
	public static void main(String args[]) throws ClassNotFoundException {
		System.out.println("Hello World");
		
		MySQLDatabaseConnection conn = new MySQLDatabaseConnection("jdbc:mysql://localhost:3306/cityofwindsor", "root", "");
		try {
			conn.getConnection();// print "Database connection established" if successful
		}catch(SQLException e) {
			System.err.println("Failed to establish database connection: " + e.getMessage());
			
		}/*finally {
            try {
                con.closeConnection();  // This will print "Database connection closed" if successful
            } catch (SQLException e) {
                System.err.println("Failed to close database connection: " + e.getMessage());
            }
		} */
		
		//Class.forName("com.mysql.cj.jdbc.Driver");
		
		
		//System.out.println("connection created");
		
		
		//This is for testing
		//UserManagement testManage = new UserManagement("C:\\Users\\jonat\\OneDrive\\Desktop\\test.txt");	
		//System.out.println(testManage.login("usernajyme3", "password3"));
			
		UIManagement frame = new UIManagement();
		frame.setVisible(true);

		for(int i = 0; i < 10; i ++) {
			CatalogEntry newEntry = new CatalogEntry("Testing Area: " + i, "Lorem ipsum dolor sit amet");
			frame.addToCatalog(newEntry);
		}
		frame.updateCatalog();
		//frame.updateDataSet();
		
	}
}
