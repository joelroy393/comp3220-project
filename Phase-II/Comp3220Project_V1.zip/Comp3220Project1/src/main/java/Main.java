import javax.swing.JButton;
import javax.swing.JFrame;

public class Main {
	public static void main(String args[]) {
		System.out.println("Hello World");
		
		
		//This is for testing
		UserManagement testManage = new UserManagement("C:\\Users\\jonat\\OneDrive\\Desktop\\test.txt");	
		System.out.println(testManage.login("usernajyme3", "password3"));
			
		UIManagement frame = new UIManagement();
		frame.setVisible(true);

		for(int i = 0; i < 10; i ++) {
			CatalogEntry newEntry = new CatalogEntry("Testing Area: " + i, "Lorem ipsum dolor sit amet");
			frame.addToCatalog(newEntry);
		}
		frame.updateCatalog();
		//frame.updateDataSet();
	}
}
