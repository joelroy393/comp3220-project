import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static java.util.Arrays.asList;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

class FilterTest {


    private List<CatalogEntry> catalogEntries;
    private Filter subject;

    @BeforeEach
    public void setUp() {
        FilePoint file1 = new FilePoint("file1.csv", "file.CSV", 1000, "CSV", "path1");
        file1.addKeyword("data");

        FilePoint file2 = new FilePoint("file2.dwg", "file.DWG", 2000, "DWG", "path2");
        file2.addKeyword("design");

        FilePoint file3 = new FilePoint("file3.kmz", "file.KMZ", 3000, "map", "path3");
        file3.addKeyword("map");

        CatalogEntry entry1 = new CatalogEntry("title", "description");
        entry1.addDownloadFiles(file1);

        CatalogEntry entry2 = new CatalogEntry("title2", "description2");
        entry2.addDownloadFiles(file2);

        CatalogEntry entry3 = new CatalogEntry("title3", "description3");
        entry3.addDownloadFiles(file3);

        catalogEntries = asList(entry1, entry2, entry3);
        subject = new Filter(catalogEntries);
    }

    @Test //Nov 17, 2024
    public void getList_whenExists_returnsCatalogs() {
        List<CatalogEntry> actual = subject.getList();

        assertThat(actual.size(), is(3));
        assertThat(actual, is(catalogEntries));
    }

    @Test
    public void filterByKeyword_whenKeywordsMatch_returnsCatalogs() {
        List<String> keywords = asList("data", "map");

        List<CatalogEntry> actual = subject.filterByKeyword(keywords);

        assertThat(actual.size(), is(2));
        assertThat(actual.contains(catalogEntries.get(0)), is(true));
        assertThat(actual.contains(catalogEntries.get(2)), is(true));
    }

    @Test
    public void filterByResourceType_whenMatches_returnsCatalogs() {
        String resourceType = "CSV";

        List<CatalogEntry> actual = subject.filterByResourceType(resourceType);

        assertThat(actual.size(), is(1));
        assertThat(actual.contains(catalogEntries.get(0)), is(true));
    }

    @Test
    public void filterByKeywordAndResourceType_whenMatches_returnsCatalogs() {
        List<String> keywords = asList("design");
        String resourceType = "DWG";

        List<CatalogEntry> actual = subject.filterByKeywordAndResourceType(keywords, resourceType);

        assertThat(actual.size(), is(1));
        assertThat(actual.contains(catalogEntries.get(1)), is(true));
    }

    @Test
    public void filterByKeywordAndResourceType_whenNoMatches_returnsEmptyCatalogs() {
        List<String> keywords = asList("data");
        String resourceType = "DWG";

        List<CatalogEntry> actual = subject.filterByKeywordAndResourceType(keywords, resourceType);

        assertThat(actual.size(), is(0));;
    }

    @Test
    public void filterByResourceType_whenNoMatches_returnsEmptyCatalogs() {
        String resourceType = "PDF";

        List<CatalogEntry> actual = subject.filterByResourceType(resourceType);

        assertThat(actual.size(), is(0));
    }

    @Test
    public void filterByKeyword_whenNoMatches_returnsEmptyCatalogs() {
        List<String> keywords = Arrays.asList("nonexistent");

        List<CatalogEntry> actual = subject.filterByKeyword(keywords);

        assertThat(actual.size(), is(0));
    }
}