Requirements:
- Eclipse
- XAMPP

Steps:
1. Put Project into the eclipse-workspace and unzip
2. Open up XAMPP and start Apache + MySQL
3. go to localhost on any browser and navigate to phpMyAdmin
4. Import the sql file located within the Database folder inside of the project
5. Run the project


Usernames and Passwords:
Username: pop
Password: pop
Status: C

Username: paul
Password: paul
Status: A