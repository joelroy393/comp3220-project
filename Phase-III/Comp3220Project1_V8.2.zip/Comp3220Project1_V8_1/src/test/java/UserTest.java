import org.junit.jupiter.api.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.*;

class UserTest {

    private User subject = new User();

    @Test
    void setEmail_whenInvalidEmail_throwsException() {
        IllegalArgumentException actual = assertThrows(IllegalArgumentException.class, () -> subject.setEmail(""));

        assertThat(actual.getMessage(), is("Invalid email format"));
    }

    @Test
    void getEmail_whenValidEmail_returnsEmail() {
        subject.setEmail("email@email.com");

        String actual = subject.getEmail();

        assertThat(actual, is("email@email.com"));
    }
}