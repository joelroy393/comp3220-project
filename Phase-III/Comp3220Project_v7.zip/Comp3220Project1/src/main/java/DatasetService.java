import java.io.File;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class DatasetService{
    private DatabaseConnection dbConnection;

    public DatasetService(DatabaseConnection dbConnection) {
        this.dbConnection = dbConnection;
    }
    public void userDashboard() {
    	
    }
    //pending dataset for contributor 
    public List<DatasetReviewEntry> getPendingDatasets(int userId) {
        List<DatasetReviewEntry> pendingDatasets = new ArrayList<>();
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT d.dataset_id, f.file_name, f.upload_date, f.file_path " +
                     "FROM datasets d " +
                     "JOIN files f ON d.dataset_id = f.dataset_id " +
                     "WHERE d.user_id = ? AND d.status = 'pending'")) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int datasetId = rs.getInt("dataset_id");
                String fileName = rs.getString("file_name");
                String uploadDate = rs.getString("upload_date");
                String filePath = rs.getString("file_path");
                pendingDatasets.add(new DatasetReviewEntry(datasetId, fileName, uploadDate, filePath));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return pendingDatasets;
    }
  //fetch pending dataset for Admin 
    public List<DatasetReviewEntry> getPendingDatasetsForAdmin() {
        List<DatasetReviewEntry> pendingDatasets = new ArrayList<>();
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT d.dataset_id, f.file_name, f.upload_date, f.file_path, u.email " +
                     "FROM datasets d " +
                     "JOIN files f ON d.dataset_id = f.dataset_id " +
                     "JOIN users u ON d.user_id = u.user_id " +
                     "WHERE d.status = 'pending'")) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int datasetId = rs.getInt("dataset_id");
                String fileName = rs.getString("file_name");
                String uploadDate = rs.getString("upload_date");
                String filePath = rs.getString("file_path");
                String email = rs.getString("email");
                pendingDatasets.add(new DatasetReviewEntry(datasetId, fileName, uploadDate, filePath, email));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return pendingDatasets;
    }
    
  //fetch Approved dataset for contributor 
    public List<DatasetReviewEntry> getApprovedDatasets(int userId) {
        List<DatasetReviewEntry> approvedDatasets = new ArrayList<>();
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT d.dataset_id, f.file_name, f.upload_date, f.file_path " +
                     "FROM datasets d " +
                     "JOIN files f ON d.dataset_id = f.dataset_id " +
                     "WHERE d.user_id = ? AND d.status = 'approved'")) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int datasetId = rs.getInt("dataset_id");
                String fileName = rs.getString("file_name");
                String uploadDate = rs.getString("upload_date");
                String filePath = rs.getString("file_path");
                approvedDatasets.add(new DatasetReviewEntry(datasetId, fileName, uploadDate, filePath));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return approvedDatasets;
    }
    
  //fetch Approved dataset for  Admin 
    public List<DatasetReviewEntry> getApprovedDatasetsByAdmin(int adminId) {
        List<DatasetReviewEntry> approvedDatasets = new ArrayList<>();
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT d.dataset_id, f.file_name, d.date_added, d.status, DATE_FORMAT(d.approval_date, '%Y-%m-%d') AS approval_date, u.email " +
                     "FROM datasets d " +
                     "JOIN files f ON d.dataset_id = f.dataset_id " +
                     "JOIN users u ON d.user_id = u.user_id " +
                     "WHERE d.approved_by = ? AND d.status = 'approved'")) {
            stmt.setInt(1, adminId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int datasetId = rs.getInt("dataset_id");
                String fileName = rs.getString("file_name");
                String dateAdded = rs.getString("date_added");
                String status = rs.getString("status");
                String approvalDate = rs.getString("approval_date");
                String email = rs.getString("email");
                approvedDatasets.add(new DatasetReviewEntry(datasetId, fileName, dateAdded, status, approvalDate, email));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return approvedDatasets;
    }


    
    
    public void updateDatasetStatus(int datasetId, String status) {
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "UPDATE datasets SET status = ?, approval_date = CURRENT_TIMESTAMP WHERE dataset_id = ?")) {
            stmt.setString(1, status);
            stmt.setInt(2, datasetId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    

    public void deleteDataset(int datasetId) {
        String filePath = null;
        try (Connection conn = dbConnection.getConnection()) {
            // Retrieve the file path before deleting the dataset
            try (PreparedStatement stmt = conn.prepareStatement("SELECT file_path FROM files WHERE dataset_id = ?")) {
                stmt.setInt(1, datasetId);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    filePath = rs.getString("file_path");
                }
            }

            // Delete from files table
            try (PreparedStatement stmt = conn.prepareStatement("DELETE FROM files WHERE dataset_id = ?")) {
                stmt.setInt(1, datasetId);
                stmt.executeUpdate();
            }

            // Delete from datasets table
            try (PreparedStatement stmt = conn.prepareStatement("DELETE FROM datasets WHERE dataset_id = ?")) {
                stmt.setInt(1, datasetId);
                stmt.executeUpdate();
            }

            // Delete the file from the file system
            if (filePath != null) {
                File file = new File(filePath);
                if (file.exists()) {
                    file.delete();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    
    
    public List<User> searchUsers(String searchText) {
        List<User> users = new ArrayList<>();
        String sql = "SELECT user_id, username, email, role, DATE_FORMAT(created_at, '%Y-%m-%d') as created_at FROM users WHERE username LIKE ? OR user_id LIKE ?";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, "%" + searchText + "%");
            stmt.setString(2, "%" + searchText + "%");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int userId = rs.getInt("user_id");
                String username = rs.getString("username");
                String email = rs.getString("email");
                String role = rs.getString("role");
                String createdAt = rs.getString("created_at"); // Use String for formatted date
                users.add(new User(userId, username, email, role, createdAt));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return users;
    }

    
    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String sql = "SELECT user_id, username, email, role, DATE_FORMAT(created_at, '%Y-%m-%d') as created_at FROM users";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int userId = rs.getInt("user_id");
                String username = rs.getString("username");
                String email = rs.getString("email");
                String role = rs.getString("role");
                String createdAt = rs.getString("created_at"); // Use String for formatted date

                users.add(new User(userId, username, email, role, createdAt));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return users;
    }


    
    
    
    public void addUser(String username, String email, String password, String role) {
        String hashedPassword = hashPassword(password);
        String sql = "INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)";

        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.setString(2, email);
            stmt.setString(3, hashedPassword);
            stmt.setString(4, role);
            stmt.executeUpdate();
        } catch (SQLException e) {
            if (e instanceof SQLIntegrityConstraintViolationException) {
                throw new IllegalArgumentException("Username or email already exists.");
            } else {
                e.printStackTrace();
            }
        }
    }

    
    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(password.getBytes());
            byte[] digest = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null; // Return null if there's an error
        }
    }

    public void deleteUser(int userId) {
        String sql = "DELETE FROM users WHERE user_id = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    

}
