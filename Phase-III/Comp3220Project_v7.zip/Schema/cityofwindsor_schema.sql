
--city of windsor database schema with relations
CREATE TABLE users ( 
	user_id INT(11) NOT NULL AUTO_INCREMENT, 
	username VARCHAR(50) NOT NULL UNIQUE, 
	email VARCHAR(100) NOT NULL UNIQUE, 
	password VARCHAR(255) NOT NULL, 
	role CHAR(1) NOT NULL DEFAULT 'C', 
	created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, 
	PRIMARY KEY (user_id) 
);


CREATE TABLE datasets (
    dataset_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,          -- Category or Title of dataset
    description TEXT,
    data_custodian INT,                   -- ID or identifier for data source
    data_currency VARCHAR(255),           -- Update frequency
    dataset_description TEXT,             -- Dataset's details
    data_accuracy TEXT,                   -- Data reliability description
    attributes TEXT,                      -- Metadata attributes of dataset
    user_id INT,                          -- Contributor reference
    category VARCHAR(255),                -- Dataset's category or title
    status ENUM('pending', 'approved') DEFAULT 'pending', -- Workflow status
    date_added TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    approval_date TIMESTAMP NULL DEFAULT NULL, -- Date approved
    file_path VARCHAR(255),               -- Path to main dataset file
	approved_by INT, 
    FOREIGN KEY (user_id) REFERENCES users(user_id)
	FOREIGN KEY (approved_by) REFERENCES users(user_id)
);


CREATE TABLE files (
    file_id INT AUTO_INCREMENT PRIMARY KEY,
    dataset_id INT,
    file_name VARCHAR(255),              -- Name with extension, e.g., filename.csv
    file_size BIGINT,                    -- File size in bytes
    file_type VARCHAR(50),               -- File type or extension, e.g., .csv, .xlsx
    file_path VARCHAR(255),              -- Path in server storage
    upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- Timestamp of file upload
    contributor_notes TEXT,              -- Optional notes by contributor
    FOREIGN KEY (dataset_id) REFERENCES datasets(dataset_id)
);

























