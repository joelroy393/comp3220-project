-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2024 at 10:34 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cityofwindsor`
--

-- --------------------------------------------------------

--
-- Table structure for table `datasets`
--

CREATE TABLE `datasets` (
  `dataset_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `data_custodian` int(11) DEFAULT NULL,
  `data_currency` varchar(255) DEFAULT NULL,
  `dataset_description` text DEFAULT NULL,
  `data_accuracy` text DEFAULT NULL,
  `attributes` longtext DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved') DEFAULT 'pending',
  `date_added` date DEFAULT curdate(),
  `approval_date` timestamp NULL DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `datasets`
--

INSERT INTO `datasets` (`dataset_id`, `title`, `description`, `data_custodian`, `data_currency`, `dataset_description`, `data_accuracy`, `attributes`, `user_id`, `category`, `status`, `date_added`, `approval_date`, `file_path`, `approved_by`) VALUES
(81, '311 Contact Centre Metrics', 'This dataset outlines a number of key performance indicators in the Windsor 311 Contact Centre calculated on a yearly basis', 75, 'The data will be updated annually and posted early in the following year.', 'This dataset outlines a number of key performance indicators in the Windsor 311 Contact Centre calculated on a yearly basis. This information is used by 311 for planning and business purposes and provides customers an understanding of the volume of interactions and overall trends.', 'This set represents data extracted from the Contact Centre phone system as well as through the customer relationship management software.', 'Calls Answered: A numerical value representing the total number of phone calls answered annually. Average Answer Delay: A numeric calculation representing the average amount of time waiting in queue prior to live answer. Service Level Target: A numeric value which measures how quickly customers are being served, expressed as a percentage of incoming calls being answered within a specific time frame. The Windsor 311 Service Level Target is 75/45 indicating that the goal is to answer 75% of calls within 45 seconds. Average Length of Call: A numeric value presented in minutes indicating the average amount of time taken to address a customer telephone interaction. First Call Resolution Rate: A numeric calculation indicating the percentage of calls that addressed the customers need on the first call thus eliminating the need to transfer that call to another department. 311 Knowledge Base Inquiries: A numeric value representing the number of inquiries categorized where questions were answered or information was provided the customer. 311 Service Requests: A numeric value representing the total number of customer initiated or proactive service requests entered in the customer relationship management software. 311 Online: A numeric value representing the total number of customer initiated service requests entered through the online channel. 311 Texts: A numeric value representing the total number of customer initiated inquiries received and responded to via the text channel. 311 Email: A numeric value representing the total number of customer initiated inquiries received and responded to via the email channel. 311 Mobile App: A numeric value representing the total number of customer initiated requests received via the Windsor 311 mobile app.', 75, '311 Contact Centre Metrics', 'approved', '2024-11-26', '2024-11-26 21:15:25', 'C:\\Users\\jonat\\eclipse-workspace\\Comp3220Project1_V8_1\\data\\311 Contact Centre Metrics\\311 Windsor Contact Centre Metrics 2021.xlsx', 75),
(82, '3-Day Parking Infraction Service Requests', 'Reports of licensed vehicles parked in the same spot for longer than 3 consecutive days. Site line issues pertaining to a fence or hedge.', 75, 'The file ending with \"_YTD.csv\" will be updated frequently, often multiple times per week. The file ending with a range will usually be posted early in the following year.', 'Reports of licensed vehicles parked in the same spot for longer than 3 consecutive days. Site line issues pertaining to a fence or hedge. The dataset contains information on customer initiated service requests entered into the City of Windsor 311 system from various channels (phone, email, online self-serve, text, mobile app). 311 manages the service request data for City of Windsor departments and divisions represented in this dataset. As such, 311 consulted the participating divisions and subject matter experts for this release. This data set is extracted electronically from the 311 customer request management system.', 'This data represents only a portion of overall City of Windsor services and the number and location of service requests will not be representative of the full range of services provided by the City of Windsor. This data represents requests for service entered into the 311 system initiated from the customer\'s perspective based on description provided by the customer at the time of contact with 311. However, during the request fulfillment process, it could be determined that the customer\'s request may not be valid or may need to be adjusted. For example a request for a tree trim is made, but upon investigation by the Forestry department it is determined that the tree is on private property and therefore the responsibility of the property owner to maintain. Review of data should take into consideration the urban attributes and context of the issue being reported, such as vegetation density, population density, age of infrastructure asset, zoning and applicable by-laws, and it should also be noted that multiple reports may be received for the same issue, which can influence results.', 'Service Request Description: A text field of the request for service description created within the 311 system. The 311 service creates requests on behalf of the customer and forwards it to the appropriate department or division for action. Department: A text field indicating the department or division responsible to follow up on the request for service. Method Received: A text field indicating the channel by which the inquiry was received: phone, email, online or text. Created Date: Numeric field indicating the date and time the service request was entered into the system. Block: Numeric field representing the block location of the reported service request. If no municipal address exists, this field will be blank. Street: Text field providing the street name location of the reported service request. Ward: Alpha numeric field indicating the political ward associated with the reported service request.', 75, '3-Day Parking Infraction Service Requests', 'approved', '2024-11-26', '2024-11-26 21:17:13', 'C:\\Users\\jonat\\eclipse-workspace\\Comp3220Project1_V8_1\\data\\3-Day Parking Infraction Service Requests\\3Day_Parking_Infraction_YTD.csv', 75),
(84, 'Abandoned Vehicle Service Requests', 'Reports of vehicles parked on roads in a state of abandonment.', 75, 'The file ending with \"_YTD.csv\" will be updated frequently, often multiple times per week. The file ending with a range will usually be posted early in the following year.', 'Reports of vehicles parked on roads in a state of abandonment. The dataset contains information on customer initiated service requests entered into the City of Windsor 311 system from various channels (phone, email, online self-serve, text, mobile app). 311 manages the service request data for City of Windsor departments and divisions represented in this dataset. As such, 311 consulted the participating divisions and subject matter experts for this release. This data set is extracted electronically from the 311 customer request management system', 'This data represents only a portion of overall City of Windsor services and the number and location of service requests will not be representative of the full range of services provided by the City of Windsor. This data represents requests for service entered into the 311 system initiated from the customer\'s perspective based on description provided by the customer at the time of contact with 311. However, during the request fulfillment process, it could be determined that the customer\'s request may not be valid or may need to be adjusted. For example a request for a tree trim is made, but upon investigation by the Forestry department it is determined that the tree is on private property and therefore the responsibility of the property owner to maintain. Review of data should take into consideration the urban attributes and context of the issue being reported, such as vegetation density, population density, age of infrastructure asset, zoning and applicable by-laws, and it should also be noted that multiple reports may be received for the same issue, which can influence results.', '​​Service Request Description: A text field of the request for service description created within the 311 system. The 311 service creates requests on behalf of the customer and forwards it to the appropriate department or division for action. Department: A text field indicating the department or division responsible to follow up on the request for service. Method Received: A text field indicating the channel by which the inquiry was received: phone, email, online or text. Created Date: Numeric field indicating the date and time the service request was entered into the system. Block: Numeric field representing the block location of the reported service request. If no municipal address exists, this field will be blank. Street: Text field providing the street name location of the reported service request. Ward: Alpha numeric field indicating the political ward associated with the reported service request.', 75, 'Abandoned Vehicle Service Requests', 'approved', '2024-11-26', '2024-11-26 21:20:22', 'C:\\Users\\jonat\\eclipse-workspace\\Comp3220Project1_V8_1\\data\\Abandoned Vehicle Service Requests\\Abandoned_Vehicle_YTD.csv', 75),
(85, 'Accessibility Concerns - Buildings Service Requests', 'Interior/exterior barriers within commercial properties. The dataset contains information on customer initiated service requests entered into the City of Windsor 311 system from various channels (phone, email, online self-serve, text, mobile app).', 75, ' The file ending with \"_YTD.csv\" will be updated frequently, often multiple times per week. The file ending with a range will usually be posted early in the following year.', 'Interior/exterior barriers within commercial properties. The dataset contains information on customer initiated service requests entered into the City of Windsor 311 system from various channels (phone, email, online self-serve, text, mobile app). 311 manages the service request data for City of Windsor departments and divisions represented in this dataset. As such, 311 consulted the participating divisions and subject matter experts for this release. This data set is extracted electronically from the 311 customer request management system.', 'This data represents only a portion of overall City of Windsor services and the number and location of service requests will not be representative of the full range of services provided by the City of Windsor. This data represents requests for service entered into the 311 system initiated from the customer\'s perspective based on description provided by the customer at the time of contact with 311. However, during the request fulfillment process, it could be determined that the customer\'s request may not be valid or may need to be adjusted. For example a request for a tree trim is made, but upon investigation by the Forestry department it is determined that the tree is on private property and therefore the responsibility of the property owner to maintain. Review of data should take into consideration the urban attributes and context of the issue being reported, such as vegetation density, population density, age of infrastructure asset, zoning and applicable by-laws, and it should also be noted that multiple reports may be received for the same issue, which can influence results.', 'Service Request Description: A text field of the request for service description created within the 311 system. The 311 service creates requests on behalf of the customer and forwards it to the appropriate department or division for action. Department: A text field indicating the department or division responsible to follow up on the request for service. Method Received: A text field indicating the channel by which the inquiry was received: phone, email, online or text. Created Date: Numeric field indicating the date and time the service request was entered into the system. Block: Numeric field representing the block location of the reported service request. If no municipal address exists, this field will be blank. Street: Text field providing the street name location of the reported service request. Ward: Alpha numeric field indicating the political ward associated with the reported service request.', 75, 'Accessibility Concerns - Buildings Service Requests', 'approved', '2024-11-26', '2024-11-26 21:22:22', 'C:\\Users\\jonat\\eclipse-workspace\\Comp3220Project1_V8_1\\data\\Accessibility Concerns - Buildings Service Requests\\Accessibility_Concerns_Building_YTD.csv', 75),
(86, 'All Service Requests', 'The dataset contains information on customer initiated service requests entered into the City of Windsor 311 system from various channels (phone, email, online self-serve, text, mobile app). 311 manages the service request data for City of Windsor departments and divisions represented in this dataset. As such, 311 consulted the participating divisions and subject matter experts for this release. This data set is extracted electronically from the 311 customer request management system.', 75, 'The file ending with \"_YTD.csv\" will be updated frequently, often multiple times per week. The file ending with a range will usually be posted early in the following year.', 'The dataset contains information on customer initiated service requests entered into the City of Windsor 311 system from various channels (phone, email, online self-serve, text, mobile app). 311 manages the service request data for City of Windsor departments and divisions represented in this dataset. As such, 311 consulted the participating divisions and subject matter experts for this release. This data set is extracted electronically from the 311 customer request management system.', 'This data represents only a portion of overall City of Windsor services and the number and location of service requests will not be representative of the full range of services provided by the City of Windsor. This data represents requests for service entered into the 311 system initiated from the customer\'s perspective based on description provided by the customer at the time of contact with 311. However, during the request fulfillment process, it could be determined that the customer\'s request may not be valid or may need to be adjusted. For example a request for a tree trim is made, but upon investigation by the Forestry department it is determined that the tree is on private property and therefore the responsibility of the property owner to maintain. Review of data should take into consideration the urban attributes and context of the issue being reported, such as vegetation density, population density, age of infrastructure asset, zoning and applicable by-laws, and it should also be noted that multiple reports may be received for the same issue, which can influence results.', 'Service Request Description: A text field of the request for service description created within the 311 system. The 311 service creates requests on behalf of the customer and forwards it to the appropriate department or division for action. Department: A text field indicating the department or division responsible to follow up on the request for service. Method Received: A text field indicating the channel by which the inquiry was received: phone, email, online or text. Created Date: Numeric field indicating the date and time the service request was entered into the system. Block: Numeric field representing the block location of the reported service request. If no municipal address exists, this field will be blank. Street: Text field providing the street name location of the reported service request. Ward: Alpha numeric field indicating the political ward associated with the reported service request.', 75, 'All Service Requests', 'approved', '2024-11-26', '2024-11-26 21:23:31', 'C:\\Users\\jonat\\eclipse-workspace\\Comp3220Project1_V8_1\\data\\All Service Requests\\AllServiceRequests_YTD.csv', 75),
(87, 'Variance Report - Quarterly', 'The quarterly operating budget variance report is a document that provides explanations and details as to the difference between the forecasted net expenditures and the corresponding budgeted figures for each of the department in the Corporation', 75, 'This report is updated 4 times per year (quarterly), typically available within one month after the variance report dates (i.e. March 31, June 30, September 30, December 31) ', 'The quarterly operating budget variance report is a document that provides explanations and details as to the difference between the forecasted net expenditures and the corresponding budgeted figures for each of the department in the Corporation', 'None', 'The quarterly operating budget variance report (Appendix A) includes a 3 year history for each department’s net budget, net expenditures and forecasted year end variances, broken down quarterly. It also includes a section to explain the quarterly variance projections, summary of the dollar variances by category, and a section for mitigating steps.', 75, 'Variance Report - Quarterly', 'approved', '2024-11-26', '2024-11-26 21:29:45', 'C:\\Users\\jonat\\eclipse-workspace\\Comp3220Project1_V8_1\\data\\Variance Report - Quarterly\\Appendix A - 2014 Q3 Variance Projections_20141027.xlsx', 75);

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `file_id` int(11) NOT NULL,
  `dataset_id` int(11) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_size` bigint(20) DEFAULT NULL,
  `file_type` varchar(50) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `upload_date` date DEFAULT curdate(),
  `contributor_notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`file_id`, `dataset_id`, `file_name`, `file_size`, `file_type`, `file_path`, `upload_date`, `contributor_notes`) VALUES
(88, 81, '311 Windsor Contact Centre Metrics 2021.xlsx', 24891, '.xlsx', 'C:\\Users\\jonat\\eclipse-workspace\\Comp3220Project1_V8_1\\data\\311 Contact Centre Metrics\\311 Windsor Contact Centre Metrics 2021.xlsx', '2024-11-26', NULL),
(89, 82, '3Day_Parking_Infraction_YTD.csv', 186050, '.csv', 'C:\\Users\\jonat\\eclipse-workspace\\Comp3220Project1_V8_1\\data\\3-Day Parking Infraction Service Requests\\3Day_Parking_Infraction_YTD.csv', '2024-11-26', NULL),
(91, 84, 'Abandoned_Vehicle_YTD.csv', 12601, '.csv', 'C:\\Users\\jonat\\eclipse-workspace\\Comp3220Project1_V8_1\\data\\Abandoned Vehicle Service Requests\\Abandoned_Vehicle_YTD.csv', '2024-11-26', NULL),
(92, 85, 'Accessibility_Concerns_Building_YTD.csv', 3230, '.csv', 'C:\\Users\\jonat\\eclipse-workspace\\Comp3220Project1_V8_1\\data\\Accessibility Concerns - Buildings Service Requests\\Accessibility_Concerns_Building_YTD.csv', '2024-11-26', NULL),
(93, 86, 'AllServiceRequests_YTD.csv', 3768172, '.csv', 'C:\\Users\\jonat\\eclipse-workspace\\Comp3220Project1_V8_1\\data\\All Service Requests\\AllServiceRequests_YTD.csv', '2024-11-26', NULL),
(94, 87, 'Appendix A - 2014 Q3 Variance Projections_20141027.xlsx', 492037, '.xlsx', 'C:\\Users\\jonat\\eclipse-workspace\\Comp3220Project1_V8_1\\data\\Variance Report - Quarterly\\Appendix A - 2014 Q3 Variance Projections_20141027.xlsx', '2024-11-26', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` char(1) NOT NULL DEFAULT 'C',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `role`, `created_at`) VALUES
(74, 'pop', 'pop@gmail.com', 'b21afc54fb48d153c19101658f4a2a48', 'C', '2024-11-17 23:34:50'),
(75, 'paul', 'paul@gmail.com', '6c63212ab48e8401eaf6b59b95d816a9', 'A', '2024-11-19 20:25:01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `datasets`
--
ALTER TABLE `datasets`
  ADD PRIMARY KEY (`dataset_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `fk_approved_by` (`approved_by`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`file_id`),
  ADD KEY `dataset_id` (`dataset_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `datasets`
--
ALTER TABLE `datasets`
  MODIFY `dataset_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `datasets`
--
ALTER TABLE `datasets`
  ADD CONSTRAINT `datasets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `fk_approved_by` FOREIGN KEY (`approved_by`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `files`
--
ALTER TABLE `files`
  ADD CONSTRAINT `files_ibfk_1` FOREIGN KEY (`dataset_id`) REFERENCES `datasets` (`dataset_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
