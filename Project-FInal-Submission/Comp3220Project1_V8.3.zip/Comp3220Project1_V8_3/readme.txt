Requirements:
- Eclipse
- XAMPP

Steps:
1. Put Project into the eclipse-workspace and unzip
2. Open up eclipse and load the project into the workspace
3. Open up XAMPP and start Apache + MySQL
4. go to localhost on any browser and navigate to phpMyAdmin
5. Import the sql file located within the Database folder inside of the project
6. Run the project


Usernames and Passwords:
Username: pop
Password: pop
Status: C

Username: paul
Password: paul
Status: A


Files:
Comp3220Project1_V8_3
	Houses the entire project
.idea
	Houses the git, compiler, and other important aspects of eclipse
.settings
	Houses the eclipse settings and preferences
_MACOSX
	Houses the mac version of the project
data
	File location that holds all the downloadable files
Database
	File that holds a copy of the sql database
src
	Holds the project code and jdbc connector
target
	Holds the compiled code that will be executed by the machine